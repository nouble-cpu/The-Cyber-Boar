from flask import Flask, render_template, redirect, request, abort, flash
from flask_login import LoginManager, login_user, login_required, logout_user, current_user

from forms.news import NewsForm
from forms.user import RegisterForm, LoginForm
from forms.site import SitesForm
from forms.quest import QuestsForm
from data.news import News
from data.sites import Sites
from data.users import User
from data.quests import Quests
from data import db_session

import random, requests

app = Flask(__name__)
login_manager = LoginManager()
login_manager.init_app(app)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


@login_manager.user_loader
def load_user(user_id):
    db_sess = db_session.create_session()
    return db_sess.query(User).get(user_id)


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect("/")


def main():
    db_session.global_init("db/blogs.db")
    app.run()


@app.route("/")
def index():
    return render_template("index2.html")


@app.route('/news', methods=['GET', 'POST'])
@login_required
def add_news():
    form = NewsForm()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        news = News()
        news.title = form.title.data
        news.content = form.content.data
        news.is_private = form.is_private.data
        current_user.news.append(news)
        db_sess.merge(current_user)
        db_sess.commit()
        return redirect('/')
    return render_template('news.html', title='Добавление новости', form=form)


@app.route('/news_delete/<int:id>', methods=['GET', 'POST'])
@login_required
def news_delete(id):
    db_sess = db_session.create_session()
    news = db_sess.query(News).filter(News.id == id, News.user == current_user).first()
    if news:
        db_sess.delete(news)
        db_sess.commit()
    else:
        abort(404)
    return redirect('/')


@app.route('/news/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_news(id):
    form = NewsForm()
    if request.method == "GET":
        db_sess = db_session.create_session()
        news = db_sess.query(News).filter(News.id == id, News.user == current_user).first()
        if news:
            form.title.data = news.title
            form.content.data = news.content
            form.is_private.data = news.is_private
        else:
            abort(404)
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        news = db_sess.query(News).filter(News.id == id, News.user == current_user).first()
        if news:
            news.title = form.title.data
            news.content = form.content.data
            news.is_private = form.is_private.data
            db_sess.commit()
            return redirect('/')
        else:
            abort(404)
    return render_template('news.html', title='Редактирование новости', form=form)


@app.route("/news_check")
def news_check():
    db_sess = db_session.create_session()
    if current_user.is_authenticated:
        news = db_sess.query(News).filter((News.user == current_user) | (News.is_private != True))
    else:
        news = db_sess.query(News).filter(News.is_private != True)
    return render_template("index.html", news=news)


@app.route('/register', methods=['GET', 'POST'])
def reqister():
    form = RegisterForm()
    if form.validate_on_submit():
        if form.password.data != form.password_again.data:
            return render_template('register.html', title='Регистрация', form=form,
                                   message="Пароли не совпадают")
        db_sess = db_session.create_session()
        if db_sess.query(User).filter(User.email == form.email.data).first():
            return render_template('register.html', title='Регистрация', form=form,
                                   message="Такой пользователь уже есть")
        user = User(
            name=form.name.data,
            email=form.email.data,
            about=form.about.data
        )
        user.set_password(form.password.data)
        db_sess.add(user)
        db_sess.commit()
        return redirect('/login')
    return render_template('register.html', title='Регистрация', form=form)


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        user = db_sess.query(User).filter(User.email == form.email.data).first()
        if user and user.check_password(form.password.data):
            login_user(user, remember=form.remember_me.data)
            return redirect("/")
        return render_template('login.html', message="Неправильный логин или пароль", form=form)
    return render_template('login.html', title='Авторизация', form=form)


@app.route('/user/<string:name>/<int:id>')
def user(name, id):
    db_sess = db_session.create_session()
    if db_sess.query(User).filter(User.id == id, User.name == name).first():
        about = User.about
        return render_template("user.html", name=name, about=about)
    else:
        return "такого пользователя не существует"

# Лекция
@app.route('/lection')
def lection():
    return render_template("lection.html")


#=======================


# Sites
@app.route('/sites', methods=['GET', 'POST'])
@login_required
def add_sites():
    form = SitesForm()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        news = Sites()
        news.title = form.title.data
        news.content = form.content.data
        news.link = form.link.data
        news.is_private = form.is_private.data
        current_user.news.append(news)
        db_sess.merge(current_user)
        db_sess.commit()
        return redirect('/')
    return render_template('sites.html', title='Добавление sites', form=form)


@app.route('/sites_delete/<int:id>', methods=['GET', 'POST'])
@login_required
def sites_delete(id):
    db_sess = db_session.create_session()
    news = db_sess.query(Sites).filter(Sites.id == id, Sites.user == current_user).first()
    if news:
        db_sess.delete(news)
        db_sess.commit()
    else:
        abort(404)
    return redirect('/')


@app.route('/sites/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_sites(id):
    form = SitesForm()
    if request.method == "GET":
        db_sess = db_session.create_session()
        news = db_sess.query(Sites).filter(Sites.id == id, Sites.user == current_user).first()
        if news:
            form.title.data = news.title
            form.content.data = news.content
            form.link.data = news.link
            form.is_private.data = news.is_private
        else:
            abort(404)
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        news = db_sess.query(Sites).filter(Sites.id == id, Sites.user == current_user).first()
        if news:
            news.title = form.title.data
            news.content = form.content.data
            news.link = form.link.data
            news.is_private = form.is_private.data
            db_sess.commit()
            return redirect('/')
        else:
            abort(404)
    return render_template('sites.html', title='Редактирование sites', form=form)


@app.route("/sites_check")
def sites_check():
    db_sess = db_session.create_session()
    if current_user.is_authenticated:
        news = db_sess.query(Sites).filter((Sites.user == current_user) | (Sites.is_private != True))
    else:
        news = db_sess.query(Sites).filter(Sites.is_private != True)
    return render_template("sites_check.html", news=news)


#===============================


@app.route('/quests', methods=['GET', 'POST'])
@login_required
def add_quests():
    form = QuestsForm()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        news = Quests()
        news.title = form.title.data
        news.content = form.content.data
        news.otvet1 = form.otvet1.data
        news.otvet2 = form.otvet2.data
        current_user.news.append(news)
        print('1')
        db_sess.merge(current_user)
        print('2')
        db_sess.commit()
        print('3')
        return redirect('/')
    return render_template('quests.html', title='Добавление квеста', form=form)


@app.route('/quests_check', methods=['GET'])
def start_question():
    db_sess = db_session.create_session()
    news = db_sess.query(Quests)
    """Отображает стартовую страницу с вопросом."""
    return render_template('quests_check.html', news=news)

@app.route('/check_quests', methods=['POST'])
def check_answer():
    """Проверяет ответ пользователя и выдает результат."""
    user_answer = request.form.get('answer')
    correct_answer = "otvet1"

    if user_answer == correct_answer:
        flash('Правильно!', category='success')
        next_url = '/next_task'  # Следующая задача или завершение игры
    else:
        flash('Неправильный ответ!', category='danger')
        next_url = '/quests_check'  # Вернуть обратно к задаче

    return redirect(next_url)

@app.route('/next_task')
def next_task():
    """Переход к следующей задаче (пример)."""
    return '<h1>Поздравляю, ты прошел этот этап!</h1>'


#===============================


# генерация пароля
@app.route('/generate_password')
def generate():
    chars = '+-/*!&$#?=@<>abcdefghijklnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890'
    length = random.randint(5, 20)
    password = ''
    for i in range(length):
        password += random.choice(chars)
    return password


# анитивирус
@app.route('/anti_virus')
def anti():
    return "здесь будет проверка сайтов на вирусы"
'''def XSS(target):
    payload = "<script>alert(XSS);</script>"
    req = requests.post(target+payload)
    if payload in req.text:
        return("XSS detected")
        return("attacking payload:"+payload)
    else:
        return("secure")'''


if __name__ == '__main__':
    main()
